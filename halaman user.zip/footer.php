<style>
        /* AWAL KAKI */
        .kaki
        {
          position: absolute;
          bottom: 0;
          padding:0;
          height: 50px;
          line-height:50px;
          width:100%;
          background-color: #908f91;
          color: white;
        }
      /* AKHIR KAKI */
</style>

<div class="kaki mt-auto">
  <p class="text-center">Copyright 2021.</p>
</div>